"""
exemplo_sintetico.py — Capítulo 3: rede sintética de 5 nós.

Percorre o roteiro do capítulo, na mesma ordem do texto:
  3.2  grafo: matriz de adjacência A, graus de saída, Laplaciana L = D_out - A
  3.3  matriz compartimental C = -L_f^T - diag(f0), com a Laplaciana PONDERADA
       pelos coeficientes da Tabela 3.1 (não é digitada à mão)
  3.4  discretização: Ad = exp(C Ts), Bd = C^{-1}(Ad - I), Ts = 1 min
  3.5  observabilidade: sensores {3,5} (adotada), {3,4} e {5}; núcleo de O,
       teste PBH e número de condicionamento kappa(O)
  3.6  simulação e Filtro de Kalman: pulso de 2,0 mm/min para 10 <= k <= 40,
       Q = 1e-3 I5, R = 1e-2 I2, K = 120 instantes. O "estado real" é gerado
       pelo próprio modelo com ruído de processo e níveis limitados a valores
       não negativos (como descrito no texto); o filtro é linear e NÃO impõe
       q >= 0.
  Tabela 3.2 (RMSE por nó) e Figura 3.2.

Semente: np.random.seed(42); os ruídos w_k e v_k são sorteados, nessa ordem,
a cada instante.

Saídas: resultados/capitulo3.json, resultados/tabela_3_2.csv,
        resultados/figuras/figura_3_2_resultado_kf.png
"""
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy.linalg import expm, null_space

RESULTADOS = Path(__file__).resolve().parent.parent / "resultados"
N = 5
TS = 1.0

# --- Seção 3.2: grafo -------------------------------------------------------
ARESTAS = [(1, 2), (2, 3), (2, 4), (3, 5), (4, 5)]
# --- Tabela 3.1: coeficientes (1/min) ----------------------------------------
F = {(1, 2): 0.30, (2, 3): 0.15, (2, 4): 0.15, (3, 5): 0.20, (4, 5): 0.20}
F0 = {1: 0.05, 5: 0.10}


def adjacencia(pesos=None):
    A = np.zeros((N, N))
    for (i, j) in ARESTAS:
        A[i - 1, j - 1] = 1.0 if pesos is None else pesos[(i, j)]
    return A


def laplaciana(A):
    return np.diag(A.sum(axis=1)) - A


def matriz_H(nos):
    H = np.zeros((len(nos), N))
    for r, n in enumerate(nos):
        H[r, n - 1] = 1.0
    return H


def matriz_O(Ad, H):
    return np.vstack([H @ np.linalg.matrix_power(Ad, k) for k in range(N)])


def main():
    res = {}
    A = adjacencia()
    L = laplaciana(A)
    res["graus_saida"] = A.sum(axis=1).astype(int).tolist()
    res["L_binaria"] = L.tolist()

    Lf = laplaciana(adjacencia(F))
    C = -Lf.T - np.diag([F0.get(i, 0.0) for i in range(1, N + 1)])
    res["C"] = np.round(C, 4).tolist()
    res["autovalores_C"] = sorted(np.round(np.linalg.eigvals(C).real, 4).tolist())

    Ad = expm(C * TS)
    Bd = np.linalg.solve(C, Ad - np.eye(N))
    res["Ad"] = np.round(Ad, 3).tolist()

    obs = {}
    for cfg in [(3, 5), (3, 4), (5,)]:
        O = matriz_O(Ad, matriz_H(cfg))
        r = int(np.linalg.matrix_rank(O))
        d = dict(posto=r)
        if r == N:
            d["kappa_O"] = float(np.linalg.cond(O))
        else:
            v = null_space(O)[:, 0]
            d["nucleo_O"] = np.round(v / np.abs(v).max(), 3).tolist()
        obs[str(cfg)] = d
    res["observabilidade"] = obs
    lam = -0.20
    res["mult_geometrica_autovalor_-0.20"] = int(N - np.linalg.matrix_rank(C - lam * np.eye(N)))

    # --- Seção 3.6: simulação + Filtro de Kalman ------------------------------
    # Convenção de tempo: q_0 = 0 e q̂_0 = 0; no passo k (k = 0, ..., K-1) a
    # entrada u_k, constante em [k, k+1) min, leva q_k a q_{k+1}, e o filtro
    # usa a medição y_{k+1}. As séries têm K + 1 amostras (t = 0, ..., K) e o
    # RMSE é calculado sobre k = 1, ..., K, como na equação do texto.
    np.random.seed(42)
    K = 120
    H = matriz_H((3, 5))
    m = H.shape[0]
    U = np.zeros((N, K))
    U[0, 10:41] = 2.0                                     # 10 <= k <= 40
    Q = 1e-3 * np.eye(N)
    R = 1e-2 * np.eye(m)
    P = np.eye(N)                                        # P_0 = I_5
    Qr, Qe = np.zeros((N, K + 1)), np.zeros((N, K + 1))  # coluna 0: q_0 = q̂_0 = 0
    Yh = np.full((m, K + 1), np.nan)                     # não há medição em t = 0
    Ps, Ks = [], []
    for k in range(K):
        w = np.random.multivariate_normal(np.zeros(N), Q)
        Qr[:, k + 1] = np.maximum(Ad @ Qr[:, k] + Bd @ U[:, k] + w, 0.0)  # "real" (>= 0)
        v = np.random.multivariate_normal(np.zeros(m), R)
        Yh[:, k + 1] = H @ Qr[:, k + 1] + v
        q_pred = Ad @ Qe[:, k] + Bd @ U[:, k]
        P_pred = Ad @ P @ Ad.T + Q
        Kk = P_pred @ H.T @ np.linalg.inv(H @ P_pred @ H.T + R)
        Qe[:, k + 1] = q_pred + Kk @ (Yh[:, k + 1] - H @ q_pred)          # sem restrição q >= 0
        P = (np.eye(N) - Kk @ H) @ P_pred
        Ps.append(P.copy())
        Ks.append(Kk.copy())

    rmse = np.sqrt(np.mean((Qe[:, 1:] - Qr[:, 1:]) ** 2, axis=1))
    res["rmse_mm"] = rmse.tolist()
    # convergência de P: primeiro instante k em que ||P_k - P_K||_F / ||P_K||_F < 10 %,
    # com P_K a covariância a posteriori no último instante (k = 120) e norma de Frobenius
    Pf = Ps[-1]
    res["convergencia_P_instantes_10pct"] = next(
        k + 1 for k, Pk in enumerate(Ps) if np.linalg.norm(Pk - Pf) / np.linalg.norm(Pf) < 0.10)
    res["ganho_estacionario_nos_medidos"] = {"no3": float(Ks[-1][2, 0]), "no5": float(Ks[-1][4, 1])}
    res["ganho_estacionario_cruzado"] = {"no3_inovacao_no5": float(Ks[-1][2, 1]),
                                         "no5_inovacao_no3": float(Ks[-1][4, 0])}
    res["ganho_estacionario_matriz"] = np.round(Ks[-1], 4).tolist()
    res["estimativa_minima_por_no_mm"] = Qe.min(axis=1).tolist()
    res["instante_estimativa_minima_no4"] = int(Qe[3].argmin())

    RESULTADOS.mkdir(parents=True, exist_ok=True)
    (RESULTADOS / "capitulo3.json").write_text(json.dumps(res, indent=2))
    with open(RESULTADOS / "tabela_3_2.csv", "w") as f:
        f.write("no,sensor,rmse_mm\n")
        for i in range(N):
            f.write(f"{i + 1},{'Sim' if i + 1 in (3, 5) else 'Não'},{rmse[i]:.4f}\n")
    figura(Qr, Qe, Yh, rmse, K)

    np.set_printoptions(precision=3, suppress=True)
    print("graus de saída:", res["graus_saida"])
    print("C =\n", np.array(res["C"]))
    print("autovalores de C:", res["autovalores_C"])
    print("Ad =\n", Ad)
    for cfg, d in obs.items():
        print(f"sensores {cfg}: rank(O) = {d['posto']}", {k: v for k, v in d.items() if k != 'posto'})
    print("multiplicidade geométrica do autovalor -0,20:", res["mult_geometrica_autovalor_-0.20"])
    print("\nTabela 3.2 — RMSE (mm):", ", ".join(f"nó {i + 1}: {r:.4f}" for i, r in enumerate(rmse)))
    print("P converge (10 %) em", res["convergencia_P_instantes_10pct"], "instantes")
    print("ganho estacionário nos nós medidos:", {k: round(v, 3) for k, v in res["ganho_estacionario_nos_medidos"].items()},
          "| termos cruzados:", {k: round(v, 4) for k, v in res["ganho_estacionario_cruzado"].items()})
    print("menor estimativa do nó 4:", f"{min(res['estimativa_minima_por_no_mm'][3], 0):.2f} mm",
          f"(t = {res['instante_estimativa_minima_no4']} min)")


def figura(Qr, Qe, Yh, rmse, K):
    nomes = ["Nó 1 — Bacia (sem sensor)", "Nó 2 — Poço de visita (sem sensor)",
             "Nó 3 — Galeria monitorada", "Nó 4 — Galeria não monitorada",
             "Nó 5 — Exutório (monitorado)"]
    sensor = {2: 0, 4: 1}
    cores = ["#1f77b4", "#ff7f0e", "#2ca02c", "#d62728", "#9467bd"]
    t = np.arange(K + 1)                      # t = 0, ..., K min
    fig, axes = plt.subplots(5, 1, figsize=(10, 13), sharex=True)
    fig.subplots_adjust(hspace=0.45)
    for i, ax in enumerate(axes):
        ax.plot(t, Qr[i], color=cores[i], lw=1.6, label="Estado real")
        ax.plot(t, Qe[i], color=cores[i], lw=1.4, ls="--", label="Estimativa (KF)")
        if i in sensor:
            ax.scatter(t[5::5], Yh[sensor[i], 5::5], color=cores[i], s=14, zorder=5,
                       label="Medição (sensor)", facecolors="none", linewidths=0.9)
        ax.axvspan(10, 41, alpha=0.08, color="blue")    # chuva em [10, 41) min
        ax.set_ylabel("Nível (mm)", fontsize=8)
        ax.set_title(nomes[i], fontsize=9, pad=3)
        ax.legend(fontsize=7, loc="upper right", framealpha=0.7)
        ax.grid(True, ls=":", lw=0.5, alpha=0.7)
        ax.set_xlim([0, K])
        ax.text(0.02, 0.93, f"RMSE = {rmse[i]:.4f} mm", transform=ax.transAxes, fontsize=7,
                va="top", bbox=dict(boxstyle="round,pad=0.2", facecolor="white", alpha=0.7))
    axes[-1].set_xlabel("Tempo (min)", fontsize=9)
    fig.suptitle("Estimação pelo Filtro de Kalman — Rede Sintética (5 nós)\n"
                 r"Entrada: pulso de chuva $u_1(k)=2{,}0$ mm/min, $10 \leq k \leq 40$",
                 fontsize=10, y=0.995)
    (RESULTADOS / "figuras").mkdir(parents=True, exist_ok=True)
    fig.savefig(RESULTADOS / "figuras" / "figura_3_2_resultado_kf.png", dpi=200,
                bbox_inches="tight", facecolor="white")
    plt.close(fig)


if __name__ == "__main__":
    main()
