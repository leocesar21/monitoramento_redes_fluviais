# Valores do PFC gerados por este repositório

Arquivo gerado automaticamente por `executar_tudo.py`.

## Capítulo 3 — rede sintética de 5 nós

- Autovalores de C: -0,35, -0,30, -0,20, -0,20, -0,10
- rank(O), sensores {3, 5}: 5; kappa(O) ≈ 56
- rank(O), sensores {3, 4}: 4 (núcleo: [0.0, 0.0, 0.0, 0.0, 1.0])
- rank(O), sensor {5}: 4 (núcleo: [-0.0, 0.0, -1.0, 1.0, -0.0])
- Convergência de P (10 %): 15 instantes
- Menor estimativa do nó 4: -0,79 mm (t = 2 min)
- Ganho estacionário nos nós medidos: nó 3 = 0,19; nó 5 = 0,27; termos cruzados 0,0375 e 0,0375
- Tabela 3.2 (RMSE, mm): nó 1 = 0,0367; nó 2 = 0,0511; nó 3 = 0,0413; nó 4 = 0,0878; nó 5 = 0,0461

## Capítulo 4 — rede SWMM de 16 nós

- Seção 4.2: max Re(autovalor) = -0,428; raio espectral de Ad = 0,652; constante de tempo mais lenta = 2,3 min
- Seção 4.2.1: alpha = 210,38; p = 0,83; erro médio de pico (J9, J13, J15, O1) = 3,3 %
- Seção 4.3: rank(O) com sensor único em J15 = 4/16; em O1 = 5/16; gramiano O1/cabeceira ≈ 47
- Tabela 4.2: 1. O1 (5/16); 2. J13 (8/16); 3. J9 (10/16); 4. J11 (12/16); 5. J1 (13/16); 6. J3 (14/16); 7. J5 (15/16); 8. J7 (16/16)
- Configuração ingênua: rank = 8/16
- kappa(O), configuração informada (16 blocos, níveis em m) = 84,7
- Continuidade do SWMM (escoamento / roteamento, %): A = -0,018 / 0,395; B = -0,065 / -1,661; C = -0,006 / 0,896
- Seção 4.5 (evento B): vazão afluente de pico na cabeceira = 0,24 m³/s; extravasamento em J1, J2, J3, J4, J5, J6, J7, J8

- Tabela 4.4 (média dos RMSE nodais, 16 nós): A = 0,0204 m; C = 0,0225 m; B = 0,1999 m
- Evento A: erro de pico médio |.| = 1,9 %, máximo 7,2 % (J12); defasagem média 2,1 min (máx. 3 min); picos no SWMM de 0,30 a 0,57 m; RMSE sensoriados 0,010 m, não sensoriados 0,031 m, gêmeos 0,036 m
- Evento C: erro de pico médio |.| = 7,8 %, máximo 20,6 % (J12); defasagem média 2,4 min (máx. 4 min); picos no SWMM de 0,21 a 0,43 m; RMSE sensoriados 0,010 m, não sensoriados 0,034 m, gêmeos 0,038 m
- Evento B: erro de pico médio |.| = 81,9 %, máximo 244,0 % (J12); defasagem média 1,8 min (máx. 6 min); picos no SWMM de 0,38 a 3,00 m; RMSE sensoriados 0,086 m, não sensoriados 0,313 m, gêmeos 0,502 m
- Evento B, diagnóstico (Seção 4.7): F = t 24–31 min (8 amostras); fração do erro quadrático em F = 97,1 %; fora de F: média dos RMSE nodais = 0,043 m, RMSE agregado = 0,046 m
- Menor estimativa (filtro sem restrição): A = -3,29 cm; C = -3,57 cm; B = -3,66 cm
- Evento B, erro de pico por nó: J1 -20 %, J2 -89 %, J3 -19 %, J4 -89 %, J5 -20 %, J6 -89 %, J7 -19 %, J8 -89 %, J9 +55 %, J10 +209 %, J11 +58 %, J12 +244 %, J13 +40 %, J14 +154 %, J15 +93 %, O1 +25 %

- Tabela 4.5: Exutório apenas (5/16) = 0,0405 m; Informada (4 primeiros) (12/16) = 0,0290 m; Informada (6 primeiros) (14/16) = 0,0252 m; Informada (8, completa) (16/16) = 0,0204 m; Ingênua (8 cabeceiras) (8/16) = 0,0169 m
- Ingênua: cabeceiras 0,011 m; nós internos 0,023 m (em malha aberta: 0,058 m)
- Tabela 4.6: σ = 0,005 → 0,0173 m; σ = 0,010 → 0,0204 m; σ = 0,030 → 0,0322 m; σ = 0,050 → 0,0392 m; σ = 0,100 → 0,0455 m
