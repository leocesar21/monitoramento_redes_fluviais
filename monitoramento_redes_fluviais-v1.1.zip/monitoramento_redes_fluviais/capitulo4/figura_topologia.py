"""
figura_topologia.py — Figura 4.1: topologia da rede de 16 nós modelada no
SWMM, destacando a configuração de sensores "informada" (Seção 4.4).

As arestas são lidas do .inp e os sensores de resultados/observabilidade.json
(saída de observabilidade.py); nada é digitado à mão.
Saída: resultados/figuras/figura_4_1_topologia.png
"""
import json
import gerar_inp as gi
import modelo as M
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# --- topologia: arvore de confluencia 8 -> 4 -> 2 -> 1 -> exutorio ---
ARESTAS = list(M.ler_inp(gi.caminho_inp("A")).edges)

SENSORES = set(json.loads((M.RESULTADOS / "observabilidade.json").read_text())["configuracao_informada"])

# posicoes: y = nivel hierarquico (montante em cima), x espalhado
POS = {}
for i, n in enumerate(["J1","J2","J3","J4","J5","J6","J7","J8"]):
    POS[n] = (i * 1.0, 3.0)
for i, n in enumerate(["J9","J10","J11","J12"]):
    POS[n] = (i * 2.0 + 0.5, 2.0)
for i, n in enumerate(["J13","J14"]):
    POS[n] = (i * 4.0 + 1.5, 1.0)
POS["J15"] = (3.5, 0.0)
POS["O1"]  = (3.5, -1.0)

C_SENSOR, C_NORMAL, C_BORDA = "#c62828", "#4a90c2", "#22384d"

fig, ax = plt.subplots(figsize=(9.0, 6.0))

for a, b in ARESTAS:
    x1, y1 = POS[a]; x2, y2 = POS[b]
    ax.annotate("", xy=(x2, y2), xytext=(x1, y1),
                arrowprops=dict(arrowstyle="-|>", lw=1.4, color="#5b6b78",
                                shrinkA=13, shrinkB=13))

for n, (x, y) in POS.items():
    sens = n in SENSORES
    ax.scatter(x, y, s=760 if n == "O1" else 620,
               c=C_SENSOR if sens else C_NORMAL,
               edgecolors=C_BORDA, linewidths=1.6,
               marker="s" if n == "O1" else "o", zorder=3)
    ax.text(x, y, n, ha="center", va="center", zorder=4,
            fontsize=9.5, color="white", fontweight="bold")

# rotulos dos niveis hierarquicos
for y, txt in [(3.0, "Cabeceiras\n(8 sub-bacias)"), (2.0, "1.º nível"),
               (1.0, "2.º nível"), (0.0, "Junção final"), (-1.0, "Exutório")]:
    ax.text(-1.35, y, txt, ha="right", va="center",
            fontsize=9, color="#41525e", style="italic")

h1 = plt.Line2D([], [], marker="o", ls="", ms=11, mfc=C_SENSOR,
                mec=C_BORDA, label="Nó instrumentado (config. informada)")
h2 = plt.Line2D([], [], marker="o", ls="", ms=11, mfc=C_NORMAL,
                mec=C_BORDA, label="Nó sem sensor (estado inferido)")
ax.legend(handles=[h1, h2], loc="upper center",
          bbox_to_anchor=(0.5, 1.10), ncol=2, frameon=False, fontsize=10)

ax.set_xlim(-4.6, 8.2); ax.set_ylim(-1.9, 3.9)
ax.axis("off")
plt.tight_layout()
(M.RESULTADOS / "figuras").mkdir(parents=True, exist_ok=True)
plt.savefig(M.RESULTADOS / "figuras" / "figura_4_1_topologia.png", dpi=300, bbox_inches="tight",
            facecolor="white")
print("figura_4_1_topologia.png gerada.")
