"""
chuva.py — Hietogramas sintéticos dos eventos A, B e C (Tabela 4.3).

Cada evento é uma lista de pares (minuto, intensidade em mm/h) com passo
de 1 min, no formato INTENSITY do SWMM: a intensidade do instante t vale
no intervalo [t, t+1) min. O mesmo sinal alimenta o modelo compartimental
(retenção de ordem zero, Ts = 1 min).
"""

DURACAO_SIMULACAO_MIN = 240  # 4 h


def triangular(lamina_mm, duracao_min, fracao_pico, dt_min=1, t_sim=DURACAO_SIMULACAO_MIN):
    """Sobe linearmente até fracao_pico*duracao e desce até o fim da chuva.
    Intensidade de pico = 2*lâmina/duração (área do triângulo = lâmina)."""
    t_pico = duracao_min * fracao_pico
    i_pico = 2.0 * lamina_mm / (duracao_min / 60.0)
    serie = []
    for t in range(0, t_sim + 1, dt_min):
        if t <= t_pico:
            i = i_pico * t / t_pico
        elif t <= duracao_min:
            i = i_pico * (duracao_min - t) / (duracao_min - t_pico)
        else:
            i = 0.0
        serie.append((t, max(i, 0.0)))
    return serie


def bloco(lamina_mm, duracao_min, inicio_min=10, dt_min=1, t_sim=DURACAO_SIMULACAO_MIN):
    """Intensidade constante lâmina/duração entre inicio e inicio+duracao."""
    i = lamina_mm / (duracao_min / 60.0)
    return [(t, i if inicio_min <= t < inicio_min + duracao_min else 0.0)
            for t in range(0, t_sim + 1, dt_min)]


EVENTOS = {
    "A": triangular(35.0, 60, fracao_pico=0.35),    # calibração, pico 70 mm/h
    "B": bloco(25.0, 20, inicio_min=10),            # extremo, 75 mm/h constantes
    "C": triangular(40.0, 120, fracao_pico=0.40),   # longo e brando, pico 40 mm/h
}

if __name__ == "__main__":
    for nome, serie in EVENTOS.items():
        lamina = sum(i for _, i in serie) / 60.0
        print(f"Evento {nome}: lâmina ≈ {lamina:.1f} mm, pico {max(i for _, i in serie):.1f} mm/h")
