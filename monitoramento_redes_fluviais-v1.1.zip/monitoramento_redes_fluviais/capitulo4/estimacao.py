"""
estimacao.py — Seções 4.6 e 4.7: Filtro de Kalman com a configuração
informada de 8 sensores nos três eventos e comparação com o SWMM.

Configuração do filtro (Seção 4.6):
  Q = (0,01)^2 I_16, R = (0,01)^2 I_8, medições = nível do SWMM nos nós
  sensoriados + ruído gaussiano de desvio-padrão 0,01 m.
  Estimativa inicial x0 = 0 (rede vazia, mesma condição inicial do SWMM)
  e covariância inicial P0 = 0,01 I_16.
  O filtro é puramente linear: nenhuma restrição (p. ex. nível >= 0) é
  imposta às estimativas nem às medições.

Semente: cada experimento usa um gerador próprio, np.random.default_rng(42),
de modo que os resultados não dependem da ordem de execução.

Produz: Tabela 4.4, erro relativo de pico e defasagem por evento, RMSE por
grupo de nós, e a Figura 4.2 (evento A).
Saídas: resultados/tabela_4_4.csv, resultados/metricas_por_no.csv,
        resultados/estimacao.json, resultados/figuras/figura_4_2_evento_A.png
"""
import json

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

import chuva as ch
import modelo as M
import rede as rd

SEMENTE = 42
SIGMA_SENSOR = 0.01   # m
SIGMA_Q = 0.01        # m
P0_ESCALA = 0.01
REGIME = {"A": "Calibração (moderado)", "C": "Robustez (longo/brando)",
          "B": "Robustez (curto/extremo, com extravasamento)"}


def executar(evento, sensores, sigma=SIGMA_SENSOR, modelo=None):
    """Roda o filtro para um evento e uma lista de sensores; retorna tudo."""
    cal = M.carregar_calibracao()
    G, nos, C, Ch, Ad, Bd = modelo or M.montar_modelo(cal["p"])
    Yref = M.carregar_referencia(evento, nos)
    N, T = Yref.shape
    U = M.entrada_nivel(ch.EVENTOS[evento], cal["alpha"], G, nos,
                        rd.SUBBACIA["pct_imperv"] / 100.0, T)
    H = M.matriz_H(nos, sensores)
    rng = np.random.default_rng(SEMENTE)
    Z = H @ Yref + sigma * rng.standard_normal((len(sensores), T))
    x0 = np.zeros(N)
    X = M.filtro_kalman(Ad, Bd, H, SIGMA_Q ** 2 * np.eye(N), sigma ** 2 * np.eye(len(sensores)),
                        U, Z, x0, P0_ESCALA * np.eye(N))
    Xab = M.malha_aberta(Ad, Bd, U, x0)
    return dict(nos=nos, Yref=Yref, X=X, Xab=Xab, Z=Z, sensores=sensores,
                posto=M.posto_observabilidade(Ad, H))


def resumo_grupo(df, filtro):
    return float(df[filtro].rmse_m.mean())


def main():
    obs = json.loads((M.RESULTADOS / "observabilidade.json").read_text())
    informada = obs["configuracao_informada"]
    cal = M.carregar_calibracao()
    modelo = M.montar_modelo(cal["p"])
    linhas, tab44, res = [], [], {}
    for ev in ["A", "C", "B"]:
        r = executar(ev, informada, modelo=modelo)
        rm = M.rmse(r["X"], r["Yref"])
        ep, df_ = M.erro_pico(r["X"], r["Yref"])
        df = pd.DataFrame(dict(evento=ev, no=r["nos"], sensoriado=[n in informada for n in r["nos"]],
                               rmse_m=rm, rmse_malha_aberta_m=M.rmse(r["Xab"], r["Yref"]),
                               erro_pico_pct=100 * ep, defasagem_pico_min=df_,
                               pico_swmm_m=r["Yref"].max(1)))
        linhas.append(df)
        tab44.append(dict(evento=ev, regime=REGIME[ev], rmse_medio_m=rm.mean()))
        gemeos = df.no.isin(["J2", "J4", "J6", "J8"])
        epa = df.erro_pico_pct.abs()
        res[ev] = dict(
            rmse_medio_m=float(rm.mean()),
            erro_pico_medio_abs_pct=float(epa.mean()),
            erro_pico_max_abs_pct=float(epa.max()),
            no_erro_pico_max=df.no[epa.idxmax()],
            defasagem_media_abs_min=float(df.defasagem_pico_min.abs().mean()),
            defasagem_max_abs_min=float(df.defasagem_pico_min.abs().max()),
            rmse_sensoriados_m=resumo_grupo(df, df.sensoriado),
            rmse_nao_sensoriados_m=resumo_grupo(df, ~df.sensoriado),
            rmse_gemeos_nao_sensoriados_m=resumo_grupo(df, gemeos),
            erro_pico_sensoriados_abs_medio_pct=float(epa[df.sensoriado].mean()),
            erro_pico_nao_sensoriados_abs_max_pct=float(epa[~df.sensoriado].max()),
            pico_swmm_min_m=float(df.pico_swmm_m.min()),
            pico_swmm_max_m=float(df.pico_swmm_m.max()),
            estimativa_minima_m=float(r["X"].min()),
            rmse_agregado_m=float(np.sqrt(np.mean((r["X"] - r["Yref"]) ** 2))),
            erro_pico_por_no_pct={n: float(v) for n, v in zip(df.no, df.erro_pico_pct)},
            rmse_por_no_m={n: float(v) for n, v in zip(df.no, df.rmse_m)},
        )
        if ev == "B":
            # Diagnóstico complementar (Seção 4.7). Na onda cinemática, o SWMM
            # não simula a sobrecarga: enquanto a afluência excede a capacidade
            # do conduto, reporta a profundidade máxima da junção (3,0 m).
            # F = instantes em que alguma cabeceira está nesse valor. O filtro
            # roda sobre a série completa; só a AVALIAÇÃO exclui F.
            #   eta_F   = sum_{k in F} sum_i e_ik^2 / sum_k sum_i e_ik^2
            #   RMSE_TF = (1/N) sum_i sqrt( mean_{k not in F} e_ik^2 )   (média dos RMSE nodais)
            Y, X = r["Yref"], r["X"]
            e2 = (X - Y) ** 2
            F = np.where((Y[:8] >= 3.0 - 1e-6).any(axis=0))[0]
            fora = np.setdiff1d(np.arange(Y.shape[1]), F)
            res[ev]["instantes_F_min"] = F.tolist()
            res[ev]["fracao_erro_quadratico_em_F"] = float(e2[:, F].sum() / e2.sum())
            res[ev]["media_rmse_nodais_fora_de_F_m"] = float(np.sqrt(e2[:, fora].mean(axis=1)).mean())
            res[ev]["rmse_agregado_fora_de_F_m"] = float(np.sqrt(e2[:, fora].mean()))
        if ev == "A":
            fig_4_2(r)

    pd.concat(linhas).to_csv(M.RESULTADOS / "metricas_por_no.csv", index=False)
    pd.DataFrame(tab44).to_csv(M.RESULTADOS / "tabela_4_4.csv", index=False)
    (M.RESULTADOS / "estimacao.json").write_text(json.dumps(res, indent=2))

    print("Tabela 4.4 — média dos RMSE nodais (16 nós), configuração informada:")
    for t in tab44:
        print(f"  {t['evento']}  {t['regime']:<45} {t['rmse_medio_m']:.4f} m")
    for ev in ["A", "C", "B"]:
        d = res[ev]
        print(f"\nEvento {ev}: erro de pico médio |.| = {d['erro_pico_medio_abs_pct']:.1f} %, "
              f"máximo = {d['erro_pico_max_abs_pct']:.1f} % ({d['no_erro_pico_max']}); "
              f"defasagem média = {d['defasagem_media_abs_min']:.1f} min (máx. {d['defasagem_max_abs_min']:.0f} min)")
        print(f"  RMSE: sensoriados {d['rmse_sensoriados_m']:.4f} m | não sensoriados "
              f"{d['rmse_nao_sensoriados_m']:.4f} m | gêmeos J2/J4/J6/J8 {d['rmse_gemeos_nao_sensoriados_m']:.4f} m")
        print(f"  picos no SWMM: {d['pico_swmm_min_m']:.2f} a {d['pico_swmm_max_m']:.2f} m; "
              f"menor estimativa: {100 * d['estimativa_minima_m']:.2f} cm")
        if ev == "B":
            F = d["instantes_F_min"]
            print(f"  instantes F com cabeceiras em 3,0 m: t = {F[0]} a {F[-1]} min ({len(F)} amostras); "
                  f"{100 * d['fracao_erro_quadratico_em_F']:.1f} % do erro quadrático; fora de F: média dos "
                  f"RMSE nodais = {d['media_rmse_nodais_fora_de_F_m']:.3f} m, RMSE agregado = "
                  f"{d['rmse_agregado_fora_de_F_m']:.3f} m")
        print("  erro de pico por nó (%): " + ", ".join(
            f"{n} {v:+.0f}" for n, v in d["erro_pico_por_no_pct"].items()))


def fig_4_2(r):
    nos = r["nos"]
    t = np.arange(r["Yref"].shape[1])
    plot = ["J1", "J9", "J13", "J15", "O1"]
    fig, axes = plt.subplots(len(plot), 1, figsize=(9, 12), sharex=True)
    for ax, n in zip(axes, plot):
        i = nos.index(n)
        ax.plot(t, r["Yref"][i], color="black", lw=1.6, label="SWMM (referência)")
        ax.plot(t, r["X"][i], color="#1f77b4", lw=1.3, ls="--", label="Estimativa (KF)")
        ax.plot(t, r["Xab"][i], color="#999999", lw=1.0, ls=":", label="Modelo (malha aberta)")
        if n in r["sensores"]:
            s = r["sensores"].index(n)
            ax.scatter(t[::10], r["Z"][s, ::10], s=10, facecolors="none", edgecolors="#d62728",
                       label="Medição (sensor)")
        ax.set_title(f"Nó {n} ({'sensoriado' if n in r['sensores'] else 'inferido'})", fontsize=9)
        ax.set_ylabel("Nível (m)", fontsize=8)
        ax.grid(True, ls=":", alpha=0.6)
    axes[0].legend(fontsize=7, loc="upper right")
    axes[-1].set_xlabel("Tempo (min)")
    fig.suptitle(f"Evento A — configuração informada (rank = {r['posto']}/{len(nos)})", fontsize=10)
    fig.tight_layout(rect=[0, 0, 1, 0.97])
    (M.RESULTADOS / "figuras").mkdir(parents=True, exist_ok=True)
    fig.savefig(M.RESULTADOS / "figuras" / "figura_4_2_evento_A.png", dpi=150)
    plt.close(fig)


if __name__ == "__main__":
    main()
