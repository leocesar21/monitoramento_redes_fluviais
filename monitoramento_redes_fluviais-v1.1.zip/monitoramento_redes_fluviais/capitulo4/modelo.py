"""
modelo.py — Modelo em grafo / compartimental, observabilidade e Filtro de
Kalman (Seções 4.2, 4.4 e 4.6; passos 1–4, 6 e 7 do Apêndice A).

Origem das entradas do modelo:
  - do arquivo .inp: topologia, cotas das junções e do exutório, e
    comprimento, rugosidade e diâmetro de cada conduto;
  - de chuva.py: os hietogramas (os mesmos escritos no .inp);
  - de rede.py: a fração impermeável das sub-bacias, usada na entrada
    (Equação 4.4);
  - deste arquivo: Ts, fator 0,6, f0 das cabeceiras e D_ref.
Editar o .inp à mão não atualiza chuva.py nem rede.py: para mudar a rede,
edite rede.py/chuva.py e gere os .inp de novo com gerar_inp.py.
"""
from pathlib import Path
import json

import networkx as nx
import numpy as np
from scipy.linalg import expm

TS_MIN = 1.0             # período de amostragem (min)
FATOR_VELOCIDADE = 0.6   # v_efetiva = 0,6 * v_plena (heurístico, Seção 4.2)
F0_CABECEIRA = 0.03      # coeficiente efetivo de perda nas cabeceiras (1/min)
D_REF = 0.40             # diâmetro de referência (condutos de cabeceira), m

RAIZ = Path(__file__).resolve().parent.parent
RESULTADOS = RAIZ / "resultados"


# ---------------------------------------------------------------------------
# Passo 1 — leitura da topologia do .inp
# ---------------------------------------------------------------------------
def ler_inp(caminho):
    secoes, atual = {}, None
    for linha in Path(caminho).read_text().splitlines():
        linha = linha.split(";")[0].strip()
        if not linha:
            continue
        if linha.startswith("["):
            atual = linha.upper()
            secoes[atual] = []
        elif atual:
            secoes[atual].append(linha.split())
    cota = {c[0]: float(c[1]) for c in secoes.get("[JUNCTIONS]", [])}
    cota.update({c[0]: float(c[1]) for c in secoes.get("[STORAGE]", [])})
    exutorios = [c[0] for c in secoes.get("[OUTFALLS]", [])]
    cota.update({c[0]: float(c[1]) for c in secoes.get("[OUTFALLS]", [])})
    diam = {c[0]: float(c[2]) for c in secoes["[XSECTIONS]"]}
    G = nx.DiGraph()
    G.add_nodes_from(cota)
    for c in secoes["[CONDUITS]"]:
        nome, de, para, comp, n = c[0], c[1], c[2], float(c[3]), float(c[4])
        G.add_edge(de, para, nome=nome, L=comp, n=n, D=diam[nome])
    for u in G.nodes:
        G.nodes[u]["cota"] = cota[u]
        G.nodes[u]["exutorio"] = u in exutorios
    return G


def ordem_nos(G):
    """Ordenação topológica estável (cabeceiras primeiro, exutório por último)."""
    return list(nx.lexicographical_topological_sort(G, key=lambda n: (n[0], int(n[1:]))))


# ---------------------------------------------------------------------------
# Passo 2 — coeficientes, Laplaciana e matriz compartimental
# ---------------------------------------------------------------------------
def velocidade_plena_manning(D, S, n):
    return (1.0 / n) * (D / 4.0) ** (2.0 / 3.0) * np.sqrt(S)


def coeficiente_transferencia(G, u, v):
    """f_uv = 1/tau_uv, tau_uv = L / (0,6 v_plena)  [1/min]."""
    e = G.edges[u, v]
    S = (G.nodes[u]["cota"] - G.nodes[v]["cota"]) / e["L"]
    assert S > 0, f"declividade não positiva no conduto {u}->{v}"
    v_ef = FATOR_VELOCIDADE * velocidade_plena_manning(e["D"], S, e["n"])
    return v_ef * 60.0 / e["L"]


def diametro_no(G, n):
    """D_i = diâmetro do conduto de jusante; no exutório, o do conduto que nele deságua."""
    saida = list(G.out_edges(n))
    if saida:
        return G.edges[saida[0]]["D"]
    (entrada,) = list(G.in_edges(n))
    return G.edges[entrada]["D"]


def matriz_compartimental(G, nos):
    """C = -L^T - diag(f0), com L = D_out - A (A ponderada por f_ij)."""
    idx = {n: i for i, n in enumerate(nos)}
    N = len(nos)
    A = np.zeros((N, N))
    for u, v in G.edges:
        A[idx[u], idx[v]] = coeficiente_transferencia(G, u, v)
    Lap = np.diag(A.sum(axis=1)) - A
    f0 = np.zeros(N)
    for n in nos:
        if G.in_degree(n) == 0:                     # cabeceira
            f0[idx[n]] = F0_CABECEIRA
        if G.nodes[n]["exutorio"]:                  # descarga do exutório
            (u, _), = G.in_edges(n)
            f0[idx[n]] = coeficiente_transferencia(G, u, n)
    return -Lap.T - np.diag(f0)


def fatores_armazenamento(G, nos, p):
    """s_i / A_ref = (D_i / D_ref)^p (Equação 4.1; A_ref se cancela em C_h)."""
    return np.array([(diametro_no(G, n) / D_REF) ** p for n in nos])


def matriz_nivel(C, G, nos, p):
    """Equação 4.2: C_h = S^{-1} C S."""
    s = fatores_armazenamento(G, nos, p)
    return np.diag(1.0 / s) @ C @ np.diag(s)


# ---------------------------------------------------------------------------
# Verificações automáticas (Seção A.3) — interrompem em caso de falha
# ---------------------------------------------------------------------------
def verificar(G, C, Ch, s, Ad):
    """C: matriz em volume; Ch = S^-1 C S: matriz em nível; s: diagonal de S."""
    assert nx.is_directed_acyclic_graph(G), "grafo possui ciclo"
    exut = [n for n in G if G.nodes[n]["exutorio"]]
    for n in G:
        assert any(nx.has_path(G, n, o) for o in exut), f"{n} sem caminho até o exutório"
    fora = ~np.eye(C.shape[0], dtype=bool)
    assert np.all(C[fora] >= 0) and np.all(Ch[fora] >= 0), "matriz não é Metzler"
    # Conservação de massa em volume: 1^T C = -f0^T <= 0
    assert np.all(C.sum(axis=0) <= 1e-12), "coluna de C com soma positiva"
    # Em nível, a identidade física é ponderada: 1^T S C_h = 1^T C S
    assert np.allclose(s @ Ch, C.sum(axis=0) * s), "balanço de volume violado em C_h"
    assert np.all(np.linalg.eigvals(C).real < 0), "autovalor de C com parte real >= 0"
    assert np.max(np.abs(np.linalg.eigvals(Ad))) < 1, "raio espectral de Ad >= 1"


# ---------------------------------------------------------------------------
# Passo 3 — discretização exata (ZOH)
# ---------------------------------------------------------------------------
def discretizar(C, Ts=TS_MIN):
    Ad = expm(C * Ts)
    Bd = np.linalg.solve(C, Ad - np.eye(C.shape[0]))
    return Ad, Bd


def entrada_nivel(serie_chuva, alpha, G, nos, fracao_imperv, T):
    """Equação 4.4: u_h,i = alpha * w_i * r(t), r em m/min; nula fora das cabeceiras."""
    r = dict(serie_chuva)
    U = np.zeros((len(nos), T))
    for i, n in enumerate(nos):
        if G.in_degree(n) == 0:
            for k in range(T):
                U[i, k] = alpha * fracao_imperv * r.get(k, 0.0) / 1000.0 / 60.0
    return U


# ---------------------------------------------------------------------------
# Passo 4 — observabilidade
# ---------------------------------------------------------------------------
def matriz_H(nos, sensores):
    H = np.zeros((len(sensores), len(nos)))
    for r, s in enumerate(sensores):
        H[r, nos.index(s)] = 1.0
    return H


def matriz_observabilidade(Ad, H):
    N = Ad.shape[0]
    return np.vstack([H @ np.linalg.matrix_power(Ad, k) for k in range(N)])


def posto_observabilidade(Ad, H):
    return int(np.linalg.matrix_rank(matriz_observabilidade(Ad, H)))


def gramiano(Ad, H, K=None):
    """Equação 2.21 com horizonte K = N (então W_o = O^T O)."""
    K = K or Ad.shape[0]
    return sum(np.linalg.matrix_power(Ad, k).T @ H.T @ H @ np.linalg.matrix_power(Ad, k)
               for k in range(K))


# ---------------------------------------------------------------------------
# Passo 6 — Filtro de Kalman (Equações 2.22–2.26), sem nenhuma restrição
# adicional sobre o estado (o filtro é puramente linear).
# ---------------------------------------------------------------------------
def filtro_kalman(Ad, Bd, H, Q, R, U, Y, x0, P0):
    """Y[:, k] é a medição no instante k; a estimativa em k usa Y[:, k].

    O ganho é obtido resolvendo um sistema linear (sem inversa explícita) e a
    covariância é atualizada na forma de Joseph, numericamente mais robusta e
    matematicamente idêntica a (I - K H) P_pred para o ganho ótimo.
    """
    N, T = Ad.shape[0], U.shape[1]
    X = np.zeros((N, T))
    X[:, 0] = x0
    P = P0.copy()
    I = np.eye(N)
    for k in range(T - 1):
        x_pred = Ad @ X[:, k] + Bd @ U[:, k]
        P_pred = Ad @ P @ Ad.T + Q
        S = H @ P_pred @ H.T + R
        K = np.linalg.solve(S, H @ P_pred).T          # K = P_pred H^T S^-1 (S simétrica)
        X[:, k + 1] = x_pred + K @ (Y[:, k + 1] - H @ x_pred)
        IKH = I - K @ H
        P = IKH @ P_pred @ IKH.T + K @ R @ K.T
    return X


def malha_aberta(Ad, Bd, U, x0):
    X = np.zeros((Ad.shape[0], U.shape[1]))
    X[:, 0] = x0
    for k in range(U.shape[1] - 1):
        X[:, k + 1] = Ad @ X[:, k] + Bd @ U[:, k]
    return X


# ---------------------------------------------------------------------------
# Passo 7 — métricas
# ---------------------------------------------------------------------------
def rmse(X, Y):
    return np.sqrt(np.mean((X - Y) ** 2, axis=1))


def erro_pico(X, Y):
    """Erro relativo de pico (fração) e defasagem do instante de pico (min)."""
    return (X.max(1) - Y.max(1)) / Y.max(1), (X.argmax(1) - Y.argmax(1)) * TS_MIN


# ---------------------------------------------------------------------------
# Utilidades comuns aos scripts do Capítulo 4
# ---------------------------------------------------------------------------
def carregar_referencia(evento, nos):
    import pandas as pd
    df = pd.read_csv(RESULTADOS / "swmm" / f"niveis_{evento}.csv")
    return df[nos].to_numpy().T          # (N, T), t = 0..239 min


def carregar_calibracao():
    return json.loads((RESULTADOS / "calibracao.json").read_text())


def montar_modelo(p):
    """Grafo lido do .inp (a geometria é a mesma nos três eventos) + C_h, Ad, Bd."""
    import gerar_inp as gi
    G = ler_inp(gi.caminho_inp("A"))
    nos = ordem_nos(G)
    C = matriz_compartimental(G, nos)
    s = fatores_armazenamento(G, nos, p)
    Ch = matriz_nivel(C, G, nos, p)
    Ad, Bd = discretizar(Ch)
    verificar(G, C, Ch, s, Ad)
    return G, nos, C, Ch, Ad, Bd
