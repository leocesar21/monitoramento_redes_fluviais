"""
simular_swmm.py — Passo 5 do Apêndice A: simulação de referência no SWMM.

Executa cada .inp via pyswmm e salva o nível (profundidade, m) de todos
os nós na grade de 1 min, contada a partir do início da simulação, que é a
referência ("verdade") usada no Capítulo 4. A simulação vai até 240 min,
mas o pyswmm não devolve o estado no instante final; as séries têm,
portanto, 240 amostras, de t = 0 a t = 239 min. Em t = 0 a rede está vazia
(profundidade inicial nula no .inp).

Registra também os erros de continuidade (%) do escoamento superficial e
do roteamento hidráulico, lidos do relatório .rpt do SWMM.

Também registra, para a discussão do evento B (Seção 4.5), a vazão
afluente de pico nas cabeceiras e os nós com extravasamento.

Saídas: resultados/swmm/niveis_{A,B,C}.csv, resultados/swmm/resumo_swmm.json
"""
import re
import json
from pathlib import Path

import numpy as np
import pandas as pd
from pyswmm import Simulation, Nodes

import gerar_inp as gi
import chuva as ch

SAIDA = Path(__file__).resolve().parent.parent / "resultados" / "swmm"


def simular(evento):
    niveis, tempos, vazao_afl, extrav = {}, [], {}, {}
    with Simulation(str(gi.caminho_inp(evento))) as sim:
        nos = Nodes(sim)
        nomes = [n.nodeid for n in nos]
        for n in nomes:
            niveis[n], vazao_afl[n], extrav[n] = [], [], 0.0
        inicio = sim.start_time
        tempos.append(0.0)                      # condição inicial: rede vazia
        for n in nomes:
            niveis[n].append(0.0)
            vazao_afl[n].append(0.0)
        for _ in sim:
            t_min = (sim.current_time - inicio).total_seconds() / 60.0
            tempos.append(t_min)
            for n in nomes:
                niveis[n].append(nos[n].depth)
                vazao_afl[n].append(nos[n].total_inflow)
                extrav[n] = max(extrav[n], nos[n].flooding)
    df = pd.DataFrame(niveis)
    df.insert(0, "t_min", tempos)
    # pyswmm avança no passo de roteamento (30 s); mantém a grade de 1 min
    df = df[np.isclose(df["t_min"] % 1.0, 0.0)].reset_index(drop=True)
    rpt = gi.caminho_inp(evento).with_suffix(".rpt").read_text()
    continuidade = [float(x) for x in re.findall(r"Continuity Error \(%\) \.+\s+(-?[\d.]+)", rpt)]
    resumo = {
        "erro_continuidade_escoamento_pct": continuidade[0],
        "erro_continuidade_roteamento_pct": continuidade[1],
        "vazao_afluente_pico_cabeceira_m3s": max(max(vazao_afl[n]) for n in ["J1"]),
        "nos_com_extravasamento": [n for n, v in extrav.items() if v > 1e-6],
        "nivel_pico_m": {n: float(df[n].max()) for n in nomes},
    }
    return df, resumo


def main():
    SAIDA.mkdir(parents=True, exist_ok=True)
    if not all(gi.caminho_inp(e).exists() for e in ch.EVENTOS):
        gi.main()
    resumo = {}
    for ev in ch.EVENTOS:
        df, r = simular(ev)
        df.to_csv(SAIDA / f"niveis_{ev}.csv", index=False)
        resumo[ev] = r
        print(f"[{ev}] {len(df)} instantes; pico cabeceira {r['nivel_pico_m']['J1']:.3f} m; "
              f"extravasamento: {r['nos_com_extravasamento'] or 'nenhum'}; continuidade "
              f"{r['erro_continuidade_escoamento_pct']:+.3f} % / {r['erro_continuidade_roteamento_pct']:+.3f} %")
    (SAIDA / "resumo_swmm.json").write_text(json.dumps(resumo, indent=2))


if __name__ == "__main__":
    main()
