"""
robustez.py — Seção 4.8: análise de robustez (evento A).

  Tabela 4.5: RMSE médio por configuração de sensores (subconjuntos da
              busca gulosa e configuração ingênua de 8 cabeceiras), mais o
              RMSE por grupo de nós usado na discussão.
  Tabela 4.6: RMSE médio em função do desvio-padrão do ruído de medição.
              Em cada nível, R é reajustado para o valor verdadeiro,
              R = sigma^2 I_8 (filtro corretamente sintonizado).

Mesma configuração de filtro e mesma semente de estimacao.py.
Saídas: resultados/tabela_4_5.csv, resultados/tabela_4_6.csv, resultados/robustez.json
"""
import json

import pandas as pd

import estimacao as est
import modelo as M

SIGMAS = [0.005, 0.010, 0.030, 0.050, 0.100]


def main():
    obs = json.loads((M.RESULTADOS / "observabilidade.json").read_text())
    gul = obs["configuracao_informada"]
    cal = M.carregar_calibracao()
    modelo = M.montar_modelo(cal["p"])
    G, nos = modelo[0], modelo[1]
    cabeceiras = [n for n in nos if G.in_degree(n) == 0]
    configs = [("Exutório apenas", gul[:1]), ("Informada (4 primeiros)", gul[:4]),
               ("Informada (6 primeiros)", gul[:6]), ("Informada (8, completa)", gul),
               ("Ingênua (8 cabeceiras)", cabeceiras)]

    tab45, grupos = [], {}
    for nome, sens in configs:
        r = est.executar("A", sens, modelo=modelo)
        rm = pd.Series(M.rmse(r["X"], r["Yref"]), index=nos)
        tab45.append(dict(configuracao=nome, sensores=len(sens), posto=f"{r['posto']}/{len(nos)}",
                          rmse_medio_m=rm.mean()))
        med = rm[sens].mean()
        nao = rm.drop(sens).mean()
        rm_ab = pd.Series(M.rmse(r["Xab"], r["Yref"]), index=nos)
        grupos[nome] = dict(rmse_sensoriados_m=float(med), rmse_nao_sensoriados_m=float(nao),
                            rmse_nao_sensoriados_malha_aberta_m=float(rm_ab.drop(sens).mean()))
    pd.DataFrame(tab45).to_csv(M.RESULTADOS / "tabela_4_5.csv", index=False)

    tab46 = []
    for s in SIGMAS:
        r = est.executar("A", gul, sigma=s, modelo=modelo)
        tab46.append(dict(desvio_padrao_sensor_m=s, rmse_medio_m=M.rmse(r["X"], r["Yref"]).mean()))
    pd.DataFrame(tab46).to_csv(M.RESULTADOS / "tabela_4_6.csv", index=False)

    (M.RESULTADOS / "robustez.json").write_text(json.dumps(
        dict(tabela_4_5=tab45, grupos=grupos, tabela_4_6=tab46), indent=2))

    print("Tabela 4.5 — RMSE médio (evento A) por configuração:")
    for t in tab45:
        print(f"  {t['configuracao']:<26} {t['sensores']}  {t['posto']:>5}  {t['rmse_medio_m']:.4f} m")
    g = grupos["Ingênua (8 cabeceiras)"]
    print(f"  ingênua: cabeceiras medidas {g['rmse_sensoriados_m']:.4f} m | "
          f"nós internos inferidos {g['rmse_nao_sensoriados_m']:.4f} m "
          f"(em malha aberta seriam {g['rmse_nao_sensoriados_malha_aberta_m']:.4f} m)")
    g = grupos["Informada (8, completa)"]
    print(f"  informada: sensoriados {g['rmse_sensoriados_m']:.4f} m | "
          f"não sensoriados {g['rmse_nao_sensoriados_m']:.4f} m")
    print("\nTabela 4.6 — RMSE médio (evento A) x ruído (R = sigma^2 I):")
    for t in tab46:
        print(f"  {t['desvio_padrao_sensor_m']:.3f} m  ->  {t['rmse_medio_m']:.4f} m")


if __name__ == "__main__":
    main()
