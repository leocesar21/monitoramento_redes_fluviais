"""
observabilidade.py — Seções 4.2 (estabilidade), 4.3 (análise topológica)
e 4.4 (observabilidade e posicionamento de sensores).

Produz:
  - autovalores de C, raio espectral de Ad, constante de tempo mais lenta;
  - Tabela 4.1: centralidade de intermediação (networkx, grafo direcionado,
    valores não normalizados);
  - posto com sensor único em J15 e em O1;
  - grau de observabilidade nodal (diagonal do gramiano, sensor em O1);
  - Tabela 4.2: busca gulosa por maximização de rank(O);
  - posto da configuração ingênua (8 cabeceiras);
  - teste PBH: autovalores distintos, multiplicidades geométricas e
    autovetor do autovalor comum a J15 e O1.

Regra de desempate da busca gulosa: entre nós com o mesmo ganho de posto,
escolhe-se o primeiro na ordenação topológica (J1, ..., J15, O1).

Saídas: resultados/observabilidade.json, resultados/tabela_4_1.csv,
        resultados/tabela_4_2.csv
"""
import json

import networkx as nx
import numpy as np
import pandas as pd

import modelo as M


def busca_gulosa(Ad, nos):
    escolhidos, historico, posto = [], [], 0
    N = len(nos)
    while posto < N:
        melhor, melhor_posto = None, posto
        for n in nos:
            if n in escolhidos:
                continue
            r = M.posto_observabilidade(Ad, M.matriz_H(nos, escolhidos + [n]))
            if r > melhor_posto:
                melhor, melhor_posto = n, r
        if melhor is None:
            raise RuntimeError("nenhum nó aumenta o posto")
        escolhidos.append(melhor)
        posto = melhor_posto
        historico.append((len(escolhidos), melhor, posto, posto == N))
    return escolhidos, historico


def main():
    cal = M.carregar_calibracao()
    G, nos, C, Ch, Ad, Bd = M.montar_modelo(cal["p"])
    N = len(nos)
    res = {}

    # --- Estabilidade (Seção 4.2) ---
    autoval = np.linalg.eigvals(Ch)
    res["autovalor_max_parte_real"] = float(autoval.real.max())
    res["raio_espectral_Ad"] = float(np.abs(np.linalg.eigvals(Ad)).max())
    res["constante_tempo_mais_lenta_min"] = float(-1 / autoval.real.max())
    res["autovalores_distintos"] = sorted({round(float(v), 6) for v in np.diag(Ch)})

    # --- Tabela 4.1 (Seção 4.3) ---
    bc = nx.betweenness_centrality(G, normalized=False)
    tab41 = pd.DataFrame({"no": nos, "intermediacao": [bc[n] for n in nos]})
    tab41.to_csv(M.RESULTADOS / "tabela_4_1.csv", index=False)
    res["intermediacao"] = {n: bc[n] for n in nos}

    # --- Sensor único: J15 (maior centralidade) vs O1 ---
    res["posto_sensor_unico_J15"] = M.posto_observabilidade(Ad, M.matriz_H(nos, ["J15"]))
    res["posto_sensor_unico_O1"] = M.posto_observabilidade(Ad, M.matriz_H(nos, ["O1"]))

    # --- Grau de observabilidade nodal (gramiano, sensor em O1) ---
    Wo = M.gramiano(Ad, M.matriz_H(nos, ["O1"]))
    diag = dict(zip(nos, np.diag(Wo)))
    res["gramiano_diag_sensor_O1"] = {n: float(v) for n, v in diag.items()}
    res["razao_gramiano_O1_sobre_cabeceira"] = float(diag["O1"] / diag["J1"])

    # --- Tabela 4.2 (Seção 4.4) ---
    escolhidos, hist = busca_gulosa(Ad, nos)
    pd.DataFrame(hist, columns=["ordem", "no_adicionado", "posto", "observavel"]).to_csv(
        M.RESULTADOS / "tabela_4_2.csv", index=False)
    res["configuracao_informada"] = escolhidos
    sv = np.linalg.svd(M.matriz_observabilidade(Ad, M.matriz_H(nos, escolhidos)), compute_uv=False)
    res["condicionamento_O_informada"] = dict(kappa=float(sv.max() / sv.min()), sigma_min=float(sv.min()),
                                              sigma_max=float(sv.max()), horizonte_blocos=N,
                                              coordenadas="níveis (m), C_h")
    res["busca_gulosa"] = hist
    cabeceiras = [n for n in nos if G.in_degree(n) == 0]
    res["posto_configuracao_ingenua"] = M.posto_observabilidade(Ad, M.matriz_H(nos, cabeceiras))

    # --- Teste PBH ---
    pbh = []
    diag_C = np.diag(Ch)
    for lam_arred in res["autovalores_distintos"]:
        lam = float(diag_C[np.isclose(diag_C, lam_arred)][0])   # valor exato
        mult_alg = int(np.sum(np.isclose(np.diag(Ch), lam)))
        mult_geo = N - int(np.linalg.matrix_rank(Ch - lam * np.eye(N), tol=1e-9))
        nos_lam = [n for n, d in zip(nos, np.diag(Ch)) if np.isclose(d, lam)]
        pbh.append(dict(autovalor=lam, mult_algebrica=mult_alg, mult_geometrica=mult_geo, nos=nos_lam))
    res["pbh"] = pbh
    lam_final = Ch[nos.index("O1"), nos.index("O1")]
    _, _, Vt = np.linalg.svd(Ch - lam_final * np.eye(N))
    v = Vt[-1]
    res["autovetor_J15_O1_componentes_nao_nulas"] = [n for n, c in zip(nos, v) if abs(c) > 1e-9]

    (M.RESULTADOS / "observabilidade.json").write_text(json.dumps(res, indent=2))

    print(f"max Re(autovalor de C) = {res['autovalor_max_parte_real']:.3f}   "
          f"raio espectral de Ad = {res['raio_espectral_Ad']:.3f}   "
          f"constante de tempo mais lenta = {res['constante_tempo_mais_lenta_min']:.1f} min")
    print("\nTabela 4.1 — intermediação:")
    print(tab41.to_string(index=False))
    print(f"\nrank(O) sensor único em J15 = {res['posto_sensor_unico_J15']}/{N}; "
          f"em O1 = {res['posto_sensor_unico_O1']}/{N}")
    print(f"gramiano (sensor O1): O1 / cabeceira = {res['razao_gramiano_O1_sobre_cabeceira']:.0f} vezes")
    print("\nTabela 4.2 — busca gulosa:")
    for o, n, r, ok in hist:
        print(f"  {o}  {n:<4} rank = {r:>2}/{N}  {'Sim' if ok else 'Não'}")
    k = res["condicionamento_O_informada"]
    print(f"kappa(O) da configuração informada = {k['kappa']:.1f} "
          f"(sigma_min = {k['sigma_min']:.4f}, sigma_max = {k['sigma_max']:.4f}; 16 blocos, níveis em m)")
    print(f"\nconfiguração ingênua (8 cabeceiras): rank = {res['posto_configuracao_ingenua']}/{N}")
    print("\nPBH:")
    for d in pbh:
        print(f"  lambda = {d['autovalor']:.4f}  mult. alg. {d['mult_algebrica']}  "
              f"mult. geo. {d['mult_geometrica']}  nós {d['nos']}")
    print(f"  autovetor do autovalor de J15/O1: não nulo apenas em "
          f"{res['autovetor_J15_O1_componentes_nao_nulas']}")


if __name__ == "__main__":
    main()
