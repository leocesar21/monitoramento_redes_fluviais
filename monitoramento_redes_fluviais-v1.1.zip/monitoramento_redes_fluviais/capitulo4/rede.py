"""
rede.py — Definição da rede sintética de 16 nós (Seção 4.1 do PFC).

Este arquivo é usado APENAS para escrever os arquivos .inp do SWMM
(gerar_inp.py). O modelo compartimental (modelo.py) não importa este
arquivo: ele lê a topologia e a geometria diretamente do .inp, conforme
o passo 1 do Apêndice A.

Topologia: árvore de confluência 8 -> 4 -> 2 -> 1 -> exutório.

    J1  J2   J3  J4   J5  J6   J7  J8      <- cabeceiras (com sub-bacia)
      \\/      \\/      \\/      \\/
      J9      J10      J11     J12         <- 1.º nível
        \\      /         \\      /
          J13                 J14          <- 2.º nível
             \\                /
                    J15                    <- junção final
                     |
                     O1                    <- exutório
"""

CABECEIRAS = [f"J{i}" for i in range(1, 9)]
NIVEL1 = ["J9", "J10", "J11", "J12"]
NIVEL2 = ["J13", "J14"]
NIVEL3 = ["J15"]
EXUTORIO = "O1"
JUNCOES = CABECEIRAS + NIVEL1 + NIVEL2 + NIVEL3

# Cota de fundo (m): decresce 1,5 m por nível -> declividade de 1 % em
# condutos de 150 m.
COTA = {**{n: 12.0 for n in CABECEIRAS}, **{n: 10.5 for n in NIVEL1},
        **{n: 9.0 for n in NIVEL2}, **{n: 7.5 for n in NIVEL3}, EXUTORIO: 6.0}

PROF_MAX_JUNCAO = 3.0   # m (teto atingido no extravasamento do evento B)
COMPRIMENTO = 150.0     # m, todos os condutos
MANNING_N = 0.013       # concreto

# (origem, destino, diâmetro [m]) — diâmetro cresce a jusante
CONDUTOS = (
    [(a, b, 0.40) for a, b in [("J1", "J9"), ("J2", "J9"), ("J3", "J10"), ("J4", "J10"),
                               ("J5", "J11"), ("J6", "J11"), ("J7", "J12"), ("J8", "J12")]]
    + [(a, b, 0.60) for a, b in [("J9", "J13"), ("J10", "J13"), ("J11", "J14"), ("J12", "J14")]]
    + [(a, b, 0.80) for a, b in [("J13", "J15"), ("J14", "J15")]]
    + [("J15", EXUTORIO, 1.00)]
)

# Sub-bacias: uma por cabeceira, 2 ha, 55 % impermeável, Horton.
SUBBACIA = dict(area_ha=2.0, pct_imperv=55.0, largura_m=120.0, declividade_pct=1.0,
                n_imperv=0.015, n_perv=0.24, s_imperv_mm=1.27, s_perv_mm=2.54,
                pct_zero=25.0,
                horton_max_mmh=76.2, horton_min_mmh=13.2, horton_decaimento=4.0,
                horton_secagem_dias=7.0)

# Coordenadas apenas para visualização no SWMM (sem significado físico).
_x = {n: i * 300 for i, n in enumerate(CABECEIRAS)}
COORDENADAS = {n: (_x[n], 4000) for n in CABECEIRAS}
for n, (a, b) in zip(NIVEL1, [("J1", "J2"), ("J3", "J4"), ("J5", "J6"), ("J7", "J8")]):
    COORDENADAS[n] = ((_x[a] + _x[b]) / 2, 3000)
COORDENADAS["J13"] = ((COORDENADAS["J9"][0] + COORDENADAS["J10"][0]) / 2, 2000)
COORDENADAS["J14"] = ((COORDENADAS["J11"][0] + COORDENADAS["J12"][0]) / 2, 2000)
COORDENADAS["J15"] = ((COORDENADAS["J13"][0] + COORDENADAS["J14"][0]) / 2, 1000)
COORDENADAS[EXUTORIO] = (COORDENADAS["J15"][0], 0)
