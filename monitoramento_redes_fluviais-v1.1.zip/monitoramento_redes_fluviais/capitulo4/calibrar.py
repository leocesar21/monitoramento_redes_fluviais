"""
calibrar.py — Seção 4.2.1: calibração dos dois parâmetros livres (alpha, p)
usando EXCLUSIVAMENTE o evento A. Os eventos B e C não são lidos aqui.

  alpha: ajustado para que o pico médio de nível nas 8 cabeceiras do modelo
         em malha aberta coincida com o pico médio do SWMM (o nível das
         cabeceiras não depende de p, pois elas não recebem afluência de
         outros nós; logo alpha é o mesmo para qualquer p).
  p:     busca em grade (0,00 a 1,20, passo 0,01) que minimiza o erro
         relativo médio de pico em J9, J13, J15 e O1.

Saída: resultados/calibracao.json (lido por todos os demais scripts).
"""
import json

import numpy as np

import chuva as ch
import modelo as M
import rede as rd

NOS_CALIBRACAO = ["J9", "J13", "J15", "O1"]
GRADE_P = np.round(np.arange(0.0, 1.2001, 0.01), 2)


def main():
    import gerar_inp as gi
    G = M.ler_inp(gi.caminho_inp("A"))
    nos = M.ordem_nos(G)
    C = M.matriz_compartimental(G, nos)
    Yref = M.carregar_referencia("A", nos)
    T = Yref.shape[1]
    w = rd.SUBBACIA["pct_imperv"] / 100.0
    cab = [nos.index(n) for n in nos if G.in_degree(n) == 0]
    cal = [nos.index(n) for n in NOS_CALIBRACAO]
    x0 = Yref[:, 0]

    melhor = None
    for p in GRADE_P:
        Ad, Bd = M.discretizar(M.matriz_nivel(C, G, nos, p))
        X1 = M.malha_aberta(Ad, Bd, M.entrada_nivel(ch.EVENTOS["A"], 1.0, G, nos, w, T), x0)
        alpha = Yref[cab].max(1).mean() / X1[cab].max(1).mean()
        X = M.malha_aberta(Ad, Bd, M.entrada_nivel(ch.EVENTOS["A"], alpha, G, nos, w, T), x0)
        erro = float(np.mean(np.abs(X[cal].max(1) - Yref[cal].max(1)) / Yref[cal].max(1)))
        if melhor is None or erro < melhor["erro_pico_medio"]:
            melhor = dict(alpha=float(alpha), p=float(p), erro_pico_medio=erro)

    (M.RESULTADOS / "calibracao.json").write_text(json.dumps(melhor, indent=2))
    print(f"alpha = {melhor['alpha']:.2f}")
    print(f"p     = {melhor['p']:.2f}")
    print(f"erro relativo médio de pico em {', '.join(NOS_CALIBRACAO)} = "
          f"{100 * melhor['erro_pico_medio']:.1f} %")


if __name__ == "__main__":
    main()
