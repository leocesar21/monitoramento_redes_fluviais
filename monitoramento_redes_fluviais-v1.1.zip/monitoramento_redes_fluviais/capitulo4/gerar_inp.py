"""
gerar_inp.py — Escreve um projeto SWMM completo (.inp) para cada evento.

Saída: capitulo4/inp/rede_pfc_{A,B,C}.inp
Roteamento por onda cinemática (KINWAVE), passo de relato de 1 min.
"""
from pathlib import Path

import rede as rd
import chuva as ch

PASTA_INP = Path(__file__).parent / "inp"

OPCOES = """[TITLE]
;; Rede sintetica de drenagem urbana - PFC (Cap. 4)

[OPTIONS]
FLOW_UNITS           CMS
INFILTRATION         HORTON
FLOW_ROUTING         KINWAVE
LINK_OFFSETS         DEPTH
MIN_SLOPE            0
ALLOW_PONDING        NO
SKIP_STEADY_STATE    NO
START_DATE           01/01/2026
START_TIME           00:00:00
REPORT_START_DATE    01/01/2026
REPORT_START_TIME    00:00:00
END_DATE             01/01/2026
END_TIME             {fim}
SWEEP_START          01/01
SWEEP_END            12/31
DRY_DAYS             0
REPORT_STEP          00:01:00
WET_STEP             00:01:00
DRY_STEP             01:00:00
ROUTING_STEP         0:00:30
RULE_STEP            00:00:00
INERTIAL_DAMPING     NONE
NORMAL_FLOW_LIMITED  BOTH
FORCE_MAIN_EQUATION  H-W
VARIABLE_STEP        0.75
LENGTHENING_STEP     0
MIN_SURFAREA         1.14
MAX_TRIALS           8
HEAD_TOLERANCE       0.0015
SYS_FLOW_TOL         5
LAT_FLOW_TOL         5
MINIMUM_STEP         0.5
THREADS              1

[EVAPORATION]
CONSTANT         0.0
DRY_ONLY         NO

[RAINGAGES]
;;Name  Format    Interval SCF  Source
RG1     INTENSITY 0:01     1.0  TIMESERIES RAIN1
"""


def hhmmss(t_min):
    s = int(round(t_min * 60))
    return f"{s // 3600:02d}:{(s % 3600) // 60:02d}:{s % 60:02d}"


def texto_inp(serie_chuva, t_sim=ch.DURACAO_SIMULACAO_MIN):
    sb = rd.SUBBACIA
    L = [OPCOES.format(fim=hhmmss(t_sim)), "[TIMESERIES]"]
    L += [f"RAIN1 01/01/2026 {hhmmss(t)} {i:.3f}" for t, i in serie_chuva]
    L += ["", "[SUBCATCHMENTS]", ";;Name Raingage Outlet Area %Imperv Width %Slope CurbLen"]
    L += [f"S_{n} RG1 {n} {sb['area_ha']:.2f} {sb['pct_imperv']:.1f} {sb['largura_m']:.1f} "
          f"{sb['declividade_pct']:.2f} 0" for n in rd.CABECEIRAS]
    L += ["", "[SUBAREAS]", ";;Subcatch N-Imperv N-Perv S-Imperv S-Perv PctZero RouteTo"]
    L += [f"S_{n} {sb['n_imperv']} {sb['n_perv']} {sb['s_imperv_mm']} {sb['s_perv_mm']} "
          f"{sb['pct_zero']:.0f} OUTLET" for n in rd.CABECEIRAS]
    L += ["", "[INFILTRATION]", ";;Subcatch MaxRate MinRate Decay DryTime MaxInfil"]
    L += [f"S_{n} {sb['horton_max_mmh']} {sb['horton_min_mmh']} {sb['horton_decaimento']:.0f} "
          f"{sb['horton_secagem_dias']:.0f} 0" for n in rd.CABECEIRAS]
    L += ["", "[JUNCTIONS]", ";;Name Elevation MaxDepth InitDepth SurDepth Aponded"]
    L += [f"{n} {rd.COTA[n]:.2f} {rd.PROF_MAX_JUNCAO:.2f} 0.00 0 0" for n in rd.JUNCOES]
    L += ["", "[OUTFALLS]", ";;Name Elevation Type StageData Gated",
          f"{rd.EXUTORIO} {rd.COTA[rd.EXUTORIO]:.2f} FREE NO"]
    L += ["", "[CONDUITS]", ";;Name From To Length Roughness InOffset OutOffset InitFlow MaxFlow"]
    L += [f"C{k} {a} {b} {rd.COMPRIMENTO:.1f} {rd.MANNING_N:.4f} 0 0 0 0"
          for k, (a, b, _) in enumerate(rd.CONDUTOS, 1)]
    L += ["", "[XSECTIONS]", ";;Link Shape Geom1 Geom2 Geom3 Geom4 Barrels"]
    L += [f"C{k} CIRCULAR {d:.2f} 0 0 0 1" for k, (_, _, d) in enumerate(rd.CONDUTOS, 1)]
    L += ["", "[COORDINATES]"]
    L += [f"{n} {x:.1f} {y:.1f}" for n, (x, y) in rd.COORDENADAS.items()]
    L += ["", "[REPORT]", "INPUT NO", "CONTROLS NO", "SUBCATCHMENTS ALL", "NODES ALL", "LINKS ALL", ""]
    return "\n".join(L)


def caminho_inp(evento):
    return PASTA_INP / f"rede_pfc_{evento}.inp"


def main():
    PASTA_INP.mkdir(exist_ok=True)
    for ev, serie in ch.EVENTOS.items():
        caminho_inp(ev).write_text(texto_inp(serie))
        print("escrito:", caminho_inp(ev))


if __name__ == "__main__":
    main()
