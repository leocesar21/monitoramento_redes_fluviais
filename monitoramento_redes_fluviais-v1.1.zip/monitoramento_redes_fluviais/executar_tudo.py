"""
executar_tudo.py — Reproduz todos os resultados numéricos do PFC, na ordem
do Apêndice A, e escreve resultados/valores_do_pfc.md com cada número
associado à seção, tabela ou figura em que aparece no texto.

Uso:  python executar_tudo.py
"""
import json
import runpy
import sys
from pathlib import Path

RAIZ = Path(__file__).resolve().parent
RES = RAIZ / "resultados"

ETAPAS = [
    ("capitulo3", "exemplo_sintetico.py"),
    ("capitulo4", "gerar_inp.py"),
    ("capitulo4", "simular_swmm.py"),
    ("capitulo4", "calibrar.py"),
    ("capitulo4", "observabilidade.py"),
    ("capitulo4", "figura_topologia.py"),
    ("capitulo4", "estimacao.py"),
    ("capitulo4", "robustez.py"),
]


def rodar(pasta, script):
    print(f"\n{'=' * 70}\n{pasta}/{script}\n{'=' * 70}")
    d = str(RAIZ / pasta)
    sys.path.insert(0, d)
    try:
        runpy.run_path(str(RAIZ / pasta / script), run_name="__main__")
    finally:
        sys.path.remove(d)


def ler(nome):
    return json.loads((RES / nome).read_text())


def br(x, casas):
    return f"{x:.{casas}f}".replace(".", ",")


def relatorio():
    c3, cal, obs = ler("capitulo3.json"), ler("calibracao.json"), ler("observabilidade.json")
    est, rob, sw = ler("estimacao.json"), ler("robustez.json"), ler("swmm/resumo_swmm.json")
    L = ["# Valores do PFC gerados por este repositório", "",
         "Arquivo gerado automaticamente por `executar_tudo.py`.", "",
         "## Capítulo 3 — rede sintética de 5 nós", "",
         f"- Autovalores de C: {', '.join(br(v, 2) for v in c3['autovalores_C'])}",
         f"- rank(O), sensores {{3, 5}}: {c3['observabilidade']['(3, 5)']['posto']}; "
         f"kappa(O) ≈ {c3['observabilidade']['(3, 5)']['kappa_O']:.0f}",
         f"- rank(O), sensores {{3, 4}}: {c3['observabilidade']['(3, 4)']['posto']} "
         f"(núcleo: {c3['observabilidade']['(3, 4)']['nucleo_O']})",
         f"- rank(O), sensor {{5}}: {c3['observabilidade']['(5,)']['posto']} "
         f"(núcleo: {c3['observabilidade']['(5,)']['nucleo_O']})",
         f"- Convergência de P (10 %): {c3['convergencia_P_instantes_10pct']} instantes",
         f"- Menor estimativa do nó 4: {br(c3['estimativa_minima_por_no_mm'][3], 2)} mm "
         f"(t = {c3['instante_estimativa_minima_no4']} min)",
         f"- Ganho estacionário nos nós medidos: nó 3 = {br(c3['ganho_estacionario_nos_medidos']['no3'], 2)}; "
         f"nó 5 = {br(c3['ganho_estacionario_nos_medidos']['no5'], 2)}; termos cruzados "
         f"{br(c3['ganho_estacionario_cruzado']['no3_inovacao_no5'], 4)} e "
         f"{br(c3['ganho_estacionario_cruzado']['no5_inovacao_no3'], 4)}",
         "- Tabela 3.2 (RMSE, mm): " + "; ".join(
             f"nó {i + 1} = {br(r, 4)}" for i, r in enumerate(c3["rmse_mm"])), "",
         "## Capítulo 4 — rede SWMM de 16 nós", "",
         f"- Seção 4.2: max Re(autovalor) = {br(obs['autovalor_max_parte_real'], 3)}; "
         f"raio espectral de Ad = {br(obs['raio_espectral_Ad'], 3)}; "
         f"constante de tempo mais lenta = {br(obs['constante_tempo_mais_lenta_min'], 1)} min",
         f"- Seção 4.2.1: alpha = {br(cal['alpha'], 2)}; p = {br(cal['p'], 2)}; "
         f"erro médio de pico (J9, J13, J15, O1) = {br(100 * cal['erro_pico_medio'], 1)} %",
         f"- Seção 4.3: rank(O) com sensor único em J15 = {obs['posto_sensor_unico_J15']}/16; "
         f"em O1 = {obs['posto_sensor_unico_O1']}/16; gramiano O1/cabeceira ≈ "
         f"{obs['razao_gramiano_O1_sobre_cabeceira']:.0f}",
         "- Tabela 4.2: " + "; ".join(f"{o}. {n} ({r}/16)" for o, n, r, _ in obs["busca_gulosa"]),
         f"- Configuração ingênua: rank = {obs['posto_configuracao_ingenua']}/16",
         f"- kappa(O), configuração informada (16 blocos, níveis em m) = "
         f"{br(obs['condicionamento_O_informada']['kappa'], 1)}",
         "- Continuidade do SWMM (escoamento / roteamento, %): " + "; ".join(
             f"{ev} = {br(sw[ev]['erro_continuidade_escoamento_pct'], 3)} / "
             f"{br(sw[ev]['erro_continuidade_roteamento_pct'], 3)}" for ev in ["A", "B", "C"]),
         f"- Seção 4.5 (evento B): vazão afluente de pico na cabeceira = "
         f"{br(sw['B']['vazao_afluente_pico_cabeceira_m3s'], 2)} m³/s; extravasamento em "
         f"{', '.join(sw['B']['nos_com_extravasamento'])}", ""]
    L += ["- Tabela 4.4 (média dos RMSE nodais, 16 nós): " + "; ".join(
        f"{ev} = {br(est[ev]['rmse_medio_m'], 4)} m" for ev in ["A", "C", "B"])]
    for ev in ["A", "C", "B"]:
        d = est[ev]
        L.append(f"- Evento {ev}: erro de pico médio |.| = {br(d['erro_pico_medio_abs_pct'], 1)} %, "
                 f"máximo {br(d['erro_pico_max_abs_pct'], 1)} % ({d['no_erro_pico_max']}); defasagem média "
                 f"{br(d['defasagem_media_abs_min'], 1)} min (máx. {d['defasagem_max_abs_min']:.0f} min); "
                 f"picos no SWMM de {br(d['pico_swmm_min_m'], 2)} a {br(d['pico_swmm_max_m'], 2)} m; "
                 f"RMSE sensoriados {br(d['rmse_sensoriados_m'], 3)} m, não sensoriados "
                 f"{br(d['rmse_nao_sensoriados_m'], 3)} m, gêmeos {br(d['rmse_gemeos_nao_sensoriados_m'], 3)} m")
    F = est["B"]["instantes_F_min"]
    L.append(f"- Evento B, diagnóstico (Seção 4.7): F = t {F[0]}–{F[-1]} min ({len(F)} amostras); "
             f"fração do erro quadrático em F = {br(100 * est['B']['fracao_erro_quadratico_em_F'], 1)} %; "
             f"fora de F: média dos RMSE nodais = {br(est['B']['media_rmse_nodais_fora_de_F_m'], 3)} m, "
             f"RMSE agregado = {br(est['B']['rmse_agregado_fora_de_F_m'], 3)} m")
    L.append("- Menor estimativa (filtro sem restrição): " + "; ".join(
        f"{ev} = {br(100 * est[ev]['estimativa_minima_m'], 2)} cm" for ev in ["A", "C", "B"]))
    b = est["B"]["erro_pico_por_no_pct"]
    L.append("- Evento B, erro de pico por nó: " + ", ".join(f"{n} {v:+.0f} %" for n, v in b.items()))
    L += ["", "- Tabela 4.5: " + "; ".join(
        f"{t['configuracao']} ({t['posto']}) = {br(t['rmse_medio_m'], 4)} m" for t in rob["tabela_4_5"])]
    g = rob["grupos"]["Ingênua (8 cabeceiras)"]
    L.append(f"- Ingênua: cabeceiras {br(g['rmse_sensoriados_m'], 3)} m; nós internos "
             f"{br(g['rmse_nao_sensoriados_m'], 3)} m (em malha aberta: "
             f"{br(g['rmse_nao_sensoriados_malha_aberta_m'], 3)} m)")
    L.append("- Tabela 4.6: " + "; ".join(
        f"σ = {br(t['desvio_padrao_sensor_m'], 3)} → {br(t['rmse_medio_m'], 4)} m" for t in rob["tabela_4_6"]))
    (RES / "valores_do_pfc.md").write_text("\n".join(L) + "\n")
    print(f"\nRelatório escrito em {RES / 'valores_do_pfc.md'}")


if __name__ == "__main__":
    for pasta, script in ETAPAS:
        rodar(pasta, script)
    relatorio()
